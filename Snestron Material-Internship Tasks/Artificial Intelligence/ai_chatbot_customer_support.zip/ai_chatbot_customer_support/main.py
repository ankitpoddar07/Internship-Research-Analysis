from chatbot.model import get_response
import streamlit as st

st.set_page_config(page_title="AI Chatbot", page_icon="🤖")

st.title("🤖 AI Chatbot for Customer Support")
user_input = st.text_input("You:", "")

if user_input:
    reply = get_response(user_input)
    st.text_area("Bot:", value=reply, height=100)