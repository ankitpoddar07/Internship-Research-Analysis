from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from database.task_db import TaskDatabase
from kivy.properties import ObjectProperty
from kivy.lang import Builder
from datetime import datetime

Builder.load_file("task.kv")

db = TaskDatabase("tasks.db")

class HomeScreen(Screen):
    task_list = ObjectProperty(None)

    def on_pre_enter(self):
        self.task_list.clear_widgets()
        tasks = db.get_all_tasks()
        for task in tasks:
            self.task_list.add_widget(Label(text=f"{task[1]} - {task[3]}"))

class AddTaskScreen(Screen):
    title_input = ObjectProperty(None)
    desc_input = ObjectProperty(None)
    date_input = ObjectProperty(None)

    def add_task(self):
        title = self.title_input.text
        desc = self.desc_input.text
        date = self.date_input.text
        if title and date:
            db.add_task(title, desc, date)
            self.manager.current = 'home'

class TaskTrackerApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(HomeScreen(name='home'))
        sm.add_widget(AddTaskScreen(name='add'))
        return sm

if __name__ == "__main__":
    TaskTrackerApp().run()
