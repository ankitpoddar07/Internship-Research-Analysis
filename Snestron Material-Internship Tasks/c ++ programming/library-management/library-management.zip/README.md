# Library Management System

## Overview
A simple C++ console-based library management system.

## Features
- Add books and users
- Issue and return books
- Display all book details
- Date utility for logging

## Requirements
- C++11 compatible compiler
- Make

## Build Instructions
```bash
make
./library_app
```

## Author
Generated via ChatGPT Library Management Template